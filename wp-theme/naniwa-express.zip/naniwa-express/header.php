<?php
/**
 * 共通ヘッダー
 *
 * @package naniwa
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
  <p class="header-topbar">横浜・川崎・東京・神奈川で引越しなら「安心・丁寧・格安」がモットーの、なにわ引越センターへ。</p>
  <div class="header-main">
    <p class="header-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( '/assets/img/logo.svg' ) ); ?>" alt="なにわ引越センター NANIWA EXPRESS" width="220" height="57"></a></p>
    <div class="header-contact">
      <p class="header-tel">
        <a href="tel:0120562728">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
          0120-562-728</a>
        <small>受付 9:00〜20:00（年中無休）</small>
      </p>
      <div class="header-cta">
        <a class="btn btn-line btn-line-h" href="https://page.line.me/168xzwvo" target="_blank" rel="noopener">LINEで相談</a>
        <a class="btn btn-primary" href="<?php echo esc_url( naniwa_page_url( 'estimate-step1' ) ); ?>">無料お見積もり</a>
      </div>
      <button class="nav-toggle" aria-expanded="false" aria-controls="drawer" aria-label="メニューを開く">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>
</header>

<!-- ドロワーメニュー -->
<div class="drawer-overlay" hidden></div>
<div class="drawer" id="drawer" hidden aria-label="メニュー">
  <div class="drawer-inner">
    <div class="drawer-head">
      <a class="drawer-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( get_theme_file_uri( '/assets/img/logo.svg' ) ); ?>" alt="なにわ引越センター" width="180" height="47"></a>
      <button class="drawer-close" aria-label="メニューを閉じる">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
      </button>
    </div>

    <nav class="drawer-nav">
      <div class="drawer-group">
        <h3>引越プランを探す</h3>
        <ul class="drawer-plans">
          <li><a href="<?php echo esc_url( naniwa_page_url( 'single' ) ); ?>"><span class="ico"><img src="<?php echo esc_url( get_theme_file_uri( '/assets/img/chars/ico-single.svg' ) ); ?>" alt="" loading="lazy"></span>単身<em>の引越</em></a></li>
          <li><a href="<?php echo esc_url( naniwa_page_url( 'family' ) ); ?>"><span class="ico"><img src="<?php echo esc_url( get_theme_file_uri( '/assets/img/chars/ico-family.svg' ) ); ?>" alt="" loading="lazy"></span>ご家族<em>の引越</em></a></li>
          <li><a href="<?php echo esc_url( naniwa_page_url( 'couple' ) ); ?>"><span class="ico"><img src="<?php echo esc_url( get_theme_file_uri( '/assets/img/chars/ico-couple.svg' ) ); ?>" alt="" loading="lazy"></span>カップル<em>の引越</em></a></li>
          <li><a href="<?php echo esc_url( naniwa_page_url( 'now' ) ); ?>"><span class="ico"><img src="<?php echo esc_url( get_theme_file_uri( '/assets/img/chars/ico-now.svg' ) ); ?>" alt="" loading="lazy"></span>今すぐ<em>の引越</em></a></li>
          <li><a href="<?php echo esc_url( naniwa_page_url( 'office' ) ); ?>"><span class="ico"><img src="<?php echo esc_url( get_theme_file_uri( '/assets/img/chars/ico-office.svg' ) ); ?>" alt="" loading="lazy"></span>オフィス<em>の引越</em></a></li>
          <li><a href="<?php echo esc_url( naniwa_page_url( 'disused' ) ); ?>"><span class="ico"><img src="<?php echo esc_url( get_theme_file_uri( '/assets/img/chars/ico-disused.svg' ) ); ?>" alt="" loading="lazy"></span>不用品処分</a></li>
        </ul>
      </div>

      <div class="drawer-group">
        <h3>引越安心ガイド</h3>
        <ul class="drawer-links">
          <li><a href="<?php echo esc_url( naniwa_page_url( 'flow' ) ); ?>">引越全体の流れ</a></li>
          <li><a href="<?php echo esc_url( naniwa_page_url( 'packing' ) ); ?>">梱包の仕方</a></li>
          <li><a href="<?php echo esc_url( naniwa_page_url( 'others' ) ); ?>">電気工事、ペット、貴重品 その他</a></li>
          <li><a href="<?php echo esc_url( naniwa_page_url( 'faq' ) ); ?>">よくあるご質問</a></li>
          <li><a href="<?php echo esc_url( naniwa_page_url( 'checklist' ) ); ?>">引越前後やることリスト</a></li>
        </ul>
      </div>

      <div class="drawer-group">
        <h3>なにわ引越センターについて</h3>
        <ul class="drawer-links">
          <li><a href="<?php echo esc_url( get_post_type_archive_link( 'voice' ) ); ?>">お客様の声</a></li>
          <li><a href="<?php echo esc_url( naniwa_page_url( 'company' ) ); ?>">なにわ引越センターについて</a></li>
          <li><a href="<?php echo esc_url( naniwa_blog_url() ); ?>">ブログ</a></li>
          <li><a href="<?php echo esc_url( naniwa_page_url( 'recruit' ) ); ?>">求人情報</a></li>
          <li><a href="<?php echo esc_url( naniwa_page_url( 'kiyaku' ) ); ?>">運送約款</a></li>
        </ul>
      </div>
    </nav>

    <div class="drawer-foot">
      <a class="btn btn-primary" href="<?php echo esc_url( naniwa_page_url( 'estimate-step1' ) ); ?>">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
        無料お見積もり</a>
      <a class="drawer-tel" href="tel:0120562728">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
        <span><span class="num">0120-562-728</span><small>9:00〜20:00（年中無休）</small></span>
      </a>
      <a class="btn btn-line" href="https://page.line.me/168xzwvo" target="_blank" rel="noopener">LINE公式アカウントで相談</a>
    </div>
  </div>
</div>

<main>
