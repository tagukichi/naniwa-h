<?php
/**
 * NANIWA EXPRESS テーマの初期設定
 *
 * @package naniwa
 */

defined( 'ABSPATH' ) || exit;

define( 'NANIWA_VERSION', '1.0.0' );

require_once get_theme_file_path( '/inc/pages.php' );
require_once get_theme_file_path( '/inc/page-map.php' );
require_once get_theme_file_path( '/inc/setup.php' );
require_once get_theme_file_path( '/inc/cpt.php' );
require_once get_theme_file_path( '/inc/meta-voice.php' );
require_once get_theme_file_path( '/inc/voice-fields.php' );
require_once get_theme_file_path( '/inc/template-tags.php' );
require_once get_theme_file_path( '/inc/estimate-fields.php' );
require_once get_theme_file_path( '/inc/estimate.php' );
require_once get_theme_file_path( '/inc/turnstile.php' );

/**
 * テーマサポートの宣言。
 */
function naniwa_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
}
add_action( 'after_setup_theme', 'naniwa_setup' );

/**
 * CSS / JS の読み込み。
 */
function naniwa_enqueue_assets() {
	wp_enqueue_style(
		'naniwa-style',
		get_theme_file_uri( '/assets/css/style.css' ),
		array(),
		NANIWA_VERSION
	);

	// テーマ情報用の style.css も読み込んでおく（子テーマからの上書き用）。
	wp_enqueue_style( 'naniwa-theme', get_stylesheet_uri(), array( 'naniwa-style' ), NANIWA_VERSION );

	wp_enqueue_script(
		'naniwa-main',
		get_theme_file_uri( '/assets/js/main.js' ),
		array(),
		NANIWA_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'naniwa_enqueue_assets' );

/**
 * 求人ページで Contact Form 7 のアセットを確実に読み込ませる。
 *
 * 求人フォームのショートコードは固定ページ本文ではなくカスタマイザーから
 * 出力している。本文を見てアセットの要否を判定する最適化（CF7の
 * 「自動的に読み込まない」設定やキャッシュ系プラグイン）が入っていると、
 * このページだけ CF7 の JS が読み込まれない。
 *
 * JS が無いと CF7 は Ajax ではなくページURLへ直接 POST するため、
 * ページURLへの POST を弾くサーバーでは 404 になる。
 */
function naniwa_enqueue_cf7_on_recruit() {
	if ( ! function_exists( 'wpcf7_enqueue_scripts' ) ) {
		return;
	}

	$recruit_id = naniwa_page_id( 'recruit' );
	if ( ! $recruit_id || ! is_page( $recruit_id ) ) {
		return;
	}

	if ( ! get_theme_mod( 'naniwa_recruit_form', '' ) ) {
		return;
	}

	wpcf7_enqueue_scripts();

	if ( function_exists( 'wpcf7_enqueue_styles' ) ) {
		wpcf7_enqueue_styles();
	}
}
add_action( 'wp_enqueue_scripts', 'naniwa_enqueue_cf7_on_recruit', 20 );

/**
 * 見積CTAを出さないページに body クラスを付ける。
 *
 * @param array<int, string> $classes body クラス.
 * @return array<int, string>
 */
function naniwa_body_class( $classes ) {
	if ( naniwa_hides_estimate_cta() ) {
		$classes[] = 'no-estimate-cta';
	}
	return $classes;
}
add_filter( 'body_class', 'naniwa_body_class' );

/**
 * 見積CTA（フッター上の帯・スマホ固定バー）を隠すページかどうか。
 *
 * @return bool
 */
function naniwa_hides_estimate_cta() {
	if ( ! is_page() ) {
		return false;
	}

	/**
	 * 見積CTAを隠すページ。
	 *
	 * テーマ内のページキー（recruit など）でも、実際のスラッグでも指定できる。
	 *
	 * @param array<int, string> $slugs ページキーまたはスラッグの配列.
	 */
	$keys = (array) apply_filters( 'naniwa_no_estimate_cta_slugs', array( 'recruit' ) );

	// 見積フォームの中では二重に見積CTAを出さない。
	foreach ( array_keys( naniwa_required_pages() ) as $key ) {
		if ( 0 === strpos( $key, 'estimate-' ) ) {
			$keys[] = $key;
		}
	}

	// 実際のスラッグ（recruit2 / step1 など）が想定と違っていても
	// 拾えるよう、割り当て済みのページIDで比べる。
	$current = (int) get_queried_object_id();
	foreach ( $keys as $key ) {
		if ( $current && (int) naniwa_page_id( $key ) === $current ) {
			return true;
		}
	}

	// フィルターで実際のスラッグを直接指定された場合。
	return is_page( $keys );
}

/**
 * 固定ページの旧URLを新しいURLへ転送する。
 *
 * 固定ページはスラッグを変えても、投稿と違って WordPress が旧URLを
 * 自動で転送しない。求人媒体や検索結果に残っている旧URLが 404 に
 * ならないよう、ここで 301 転送する。旧URLが 404 のときだけ動く。
 */
function naniwa_legacy_redirect() {
	if ( ! is_404() ) {
		return;
	}

	/**
	 * 旧スラッグ => ページキー。
	 *
	 * @param array<string, string> $map
	 */
	$map = (array) apply_filters(
		'naniwa_legacy_slugs',
		array(
			'recruit2'  => 'recruit',
			'recruit-2' => 'recruit',
		)
	);

	$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : '';
	$last = basename( trim( $path, '/' ) );

	if ( '' === $last || ! isset( $map[ $last ] ) ) {
		return;
	}

	$id = naniwa_page_id( $map[ $last ] );
	if ( ! $id || 'publish' !== get_post_status( $id ) ) {
		return;
	}

	$target = get_permalink( $id );
	if ( ! $target || basename( untrailingslashit( (string) wp_parse_url( $target, PHP_URL_PATH ) ) ) === $last ) {
		return; // 転送先が自分自身なら何もしない
	}

	wp_safe_redirect( $target, 301 );
	exit;
}
add_action( 'template_redirect', 'naniwa_legacy_redirect', 9 );

/**
 * 抜粋の省略記号を「…」にする。
 *
 * @return string
 */
function naniwa_excerpt_more() {
	return '…';
}
add_filter( 'excerpt_more', 'naniwa_excerpt_more' );

/**
 * 日本語向けに抜粋の文字数を調整する。
 *
 * @return int
 */
function naniwa_excerpt_length() {
	return 60;
}
add_filter( 'excerpt_length', 'naniwa_excerpt_length' );

/**
 * お客様の声・お知らせのアーカイブ表示件数。
 *
 * @param WP_Query $query メインクエリ.
 */
function naniwa_pre_get_posts( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}
	// ブログ一覧（PC 3列 × 4行）
	if ( $query->is_home() ) {
		$query->set( 'posts_per_page', 12 );
	}
	if ( $query->is_post_type_archive( 'voice' ) ) {
		$query->set( 'posts_per_page', 12 );
	}
	if ( $query->is_post_type_archive( 'topics' ) ) {
		$query->set( 'posts_per_page', 20 );
	}
}
add_action( 'pre_get_posts', 'naniwa_pre_get_posts' );

/**
 * 応募フォーム（Contact Form 7）のショートコードをカスタマイザーで設定できるようにする。
 *
 * @param WP_Customize_Manager $wp_customize カスタマイザー.
 */
function naniwa_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'naniwa_forms',
		array(
			'title'    => 'なにわ：フォーム設定',
			'priority' => 160,
		)
	);

	$wp_customize->add_setting(
		'naniwa_recruit_form',
		array(
			'default'           => '',
			'sanitize_callback' => 'wp_kses_post',
		)
	);
	$wp_customize->add_control(
		'naniwa_recruit_form',
		array(
			'label'       => '応募フォームのショートコード',
			'description' => '求人ページに表示するフォーム。例：[contact-form-7 id="123" title="応募フォーム"]　空欄の場合はデザイン確認用のダミーフォームが表示されます。',
			'section'     => 'naniwa_forms',
			'type'        => 'textarea',
		)
	);

	$wp_customize->add_setting(
		'naniwa_estimate_mail_to',
		array(
			'default'           => '',
			'sanitize_callback' => 'naniwa_clean_email_list',
		)
	);
	$wp_customize->add_control(
		'naniwa_estimate_mail_to',
		array(
			'label'       => 'web見積の通知先メールアドレス',
			'description' => '見積フォームの送信を受け取るアドレス。複数指定する場合はカンマ区切り（例：info@example.com,info@example.jp）。空欄の場合は「設定 → 一般」の管理者アドレスに送ります。',
			'section'     => 'naniwa_forms',
			'type'        => 'text',
		)
	);

	// web見積のスパム対策（Cloudflare Turnstile）
	$wp_customize->add_setting(
		'naniwa_turnstile_sitekey',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'naniwa_turnstile_sitekey',
		array(
			'label'       => 'web見積：Turnstile サイトキー',
			'description' => 'Cloudflare ダッシュボード → Turnstile で発行したキー。サイトキーとシークレットキーの両方が空欄の場合は、Contact Form 7 のインテグレーションに登録済みのキーを使います。どちらにも無ければ Turnstile は表示されません。',
			'section'     => 'naniwa_forms',
			'type'        => 'text',
		)
	);
	$wp_customize->add_setting(
		'naniwa_turnstile_secret',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'naniwa_turnstile_secret',
		array(
			'label'   => 'web見積：Turnstile シークレットキー',
			'section' => 'naniwa_forms',
			'type'    => 'text',
		)
	);
}
add_action( 'customize_register', 'naniwa_customize_register' );
