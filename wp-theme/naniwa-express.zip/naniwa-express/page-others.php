<?php
/**
 * 固定ページ：電気工事、ペット、貴重品 その他（スラッグ: others）
 *
 * Template Name: 電気工事、ペット、貴重品 その他
 *
 * @package naniwa
 */

get_header();
?>

<section class="page-head">
  <div class="inner"><div class="ph-copy">
    <span class="en">OTHERS</span>
    <h1>電気工事、ペット、貴重品 その他</h1>
    <p class="page-lead">大切なものだからこそ運べないものもあります。</p>
  </div><p class="ph-chara"><img src="<?php echo esc_url( get_theme_file_uri( '/assets/img/chars/ico-aircon-white.svg' ) ); ?>" alt=""></p></div>
</section>

<nav class="breadcrumb" aria-label="パンくずリスト">
  <div class="inner">
    <ol>
      <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">ホーム</a></li>
      <li>引越安心ガイド</li>
      <li>電気工事、ペット、貴重品 その他</li>
    </ol>
  </div>
</nav>

<div class="page-body">
  <div class="inner">

    <div class="lead-block">
      <h2><span class="mark">大切なものだからこそ</span><br>運べないものもあります。</h2>
      <p>お引越しにともなう電気工事やペットの輸送、貴重品のお取り扱いについてご案内します。</p>
    </div>

    <div class="block">
      <h2 class="h-sec">電気製品の取り付け、取り外しも承ります</h2>
      <p>なにわ引越センターではエアコン、照明、洗濯機、ウォシュレット、衛星放送アンテナ、浄水器、食器洗浄器など、電気製品の取り付け、取り外しをお受けしております。</p>
      <div class="notice-box green" style="margin-top:18px;">
        <p>電気製品の取り付け、取り外しは<strong>簡単なものはサービスとして無料</strong>とさせていただきますので、お気軽にお問い合わせください。有料オプションの料金については、お客様のお持ちになっている製品の内容によって値段が異なりますので、お見積り時にご相談ください。</p>
      </div>

      <h3 class="h-sub" style="margin-top:28px;">対応する電気製品の例</h3>
      <ul class="tag-list">
        <li>エアコン</li><li>照明</li><li>洗濯機</li><li>ウォシュレット</li>
        <li>衛星放送アンテナ</li><li>浄水器</li><li>食器洗浄器</li>
      </ul>
    </div>

    <div class="block">
      <h2 class="h-sec">ペット</h2>
      <p>当社は<strong>ペット輸送専門業者と提携</strong>しております。お気軽にお問い合わせください。</p>
      <div class="notice-box" style="margin-top:16px;">
        <p class="note">※家具運搬用トラックへの同乗はお断りしております。</p>
      </div>
    </div>

    <div class="block">
      <h2 class="h-sec">貴重品</h2>
      <p>以下のものはお客様で保管をお願いします。</p>
      <ul class="tag-list warn" style="margin-top:16px;">
        <li>現金</li><li>有価証券</li><li>通帳</li><li>印鑑</li><li>宝石 等</li>
      </ul>
      <p class="note" style="margin-top:14px;">※上記に記載の無いものも、状況によってお客様で保管をお願いする場合があります。</p>
    </div>

    <div class="block">
      <div class="notice-box green">
        <h4>ほかにもご不明な点がありましたら</h4>
        <p>お運びできないものや料金など、よくいただくご質問は<a href="<?php echo esc_url( naniwa_page_url( 'faq' ) ); ?>" style="color:var(--green-600);font-weight:700;text-decoration:underline;">よくある質問</a>にまとめています。記載のない内容は、お電話またはお見積りフォームよりお気軽にお問い合わせください。</p>
      </div>
    </div>

  </div>
</div>

<?php
get_footer();
