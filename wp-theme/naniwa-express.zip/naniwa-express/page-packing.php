<?php
/**
 * 固定ページ：梱包の仕方（スラッグ: packing）
 *
 * Template Name: 梱包の仕方
 *
 * @package naniwa
 */

get_header();
?>

<section class="page-head">
  <div class="inner"><div class="ph-copy">
    <span class="en">PACKING</span>
    <h1>梱包の仕方</h1>
    <p class="page-lead">キチンと梱包すれば、開梱も楽チン。</p>
  </div><p class="ph-chara"><img src="<?php echo esc_url( get_theme_file_uri( '/assets/img/chars/ico-carton-white.svg' ) ); ?>" alt=""></p></div>
</section>

<nav class="breadcrumb" aria-label="パンくずリスト">
  <div class="inner">
    <ol>
      <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">ホーム</a></li>
      <li>引越安心ガイド</li>
      <li>梱包の仕方</li>
    </ol>
  </div>
</nav>

<div class="page-body">
  <div class="inner">

    <div class="lead-block">
      <h2>キチンと梱包すれば、開梱も楽チン。<br><span class="mark">なにわが提案する、正しい梱包の仕方</span></h2>
      <p>「段ボールに荷物を詰める。」なんでもないことかもしれませんが、じつはそのなかにもテクニックが存在しています。正しくきちんと梱包すれば、引越後の開梱が簡単になるのはモチロンのこと。じつは引越の費用だって抑えることが出来るのです。</p>
    </div>

    <div class="block">
      <h2 class="h-sec">ダンボール箱</h2>
      <p>引越しに使う段ボールは何でもいいわけではありません。段ボールには種類があり、コシがないものは引越しに適していません。効率よくトラックに積むことを考えると、引越業者が用意するものなど寸法が一定で厚みもある引越用の段ボールを用意することをお勧めします。</p>
      <div class="notice-box green" style="margin-top:16px;">
        <p>当社では引越しの量に合わせて<strong>無料で段ボールを提供</strong>しております。足りない場合は販売もしておりますので、お気軽にお問い合わせください。</p>
      </div>

      <h3 class="h-sub" style="margin-top:32px;">段ボール箱の使い分け方</h3>
      <div class="card-grid">
        <div class="info-card">
          <h3>大きい段ボール</h3>
          <p>衣類などの軽い物を入れます。かさばるけれど軽いものに向いています。</p>
        </div>
        <div class="info-card">
          <h3>小さい段ボール</h3>
          <p>本や食器等の重い物を入れます。本の量が多いとついつい大きな段ボールにまとめたくなりますが、普通の人では持ち上げられない重さになってしまいます。中に入れるお荷物に適した段ボールを選びましょう。</p>
        </div>
      </div>

      <h3 class="h-sub" style="margin-top:32px;">組み立て方・詰め方</h3>
      <div class="steps">
        <div class="step-item">
          <div class="step-no"></div>
          <div class="step-body">
            <h3>ガムテープを十字に貼る</h3>
            <p>底が抜けないようにしっかりと固定します。</p>
            <p class="note">※底は、交互に組まないようにしてください。底が抜ける場合があります。</p>
          </div>
        </div>
        <div class="step-item">
          <div class="step-no"></div>
          <div class="step-body">
            <h3>荷物を詰める</h3>
            <p class="note">※隙間がある場合は新聞紙などで隙間を埋めます。割れ物は特に注意してください。</p>
          </div>
        </div>
        <div class="step-item">
          <div class="step-no"></div>
          <div class="step-body">
            <h3>上面はテープ一本で止める</h3>
            <p class="note">※あまりテープを貼りすぎると手が滑ります。</p>
          </div>
        </div>
        <div class="step-item">
          <div class="step-no"></div>
          <div class="step-body">
            <h3>中身が分かるよう、名前を書く</h3>
            <p>引越前に中身のものが急に必要になった時、搬入や荷解きの際に役立ちます。</p>
          </div>
        </div>
      </div>

      <div class="notice-box" style="margin-top:24px;">
        <h4>段ボールに収まらないもの</h4>
        <p>荷物は袋に入れたりヒモでしばったりせず、段ボールに入れてください。段ボールに入らないものに関しては、お問い合わせください。フタはなるべく閉めて上からテープを貼ってください。</p>
      </div>
    </div>

    <div class="block">
      <h2 class="h-sec">食器</h2>
      <p>割れ物の代表格と言えるのが食器。意外と食器の梱包の仕方を知らない方も多いので、あらためて予習しておきましょう。</p>

      <h3 class="h-sub" style="margin-top:26px;">お皿の梱包</h3>
      <ul class="check-list">
        <li>お皿は1枚ずつ包みます。</li>
        <li>四隅から中心に向かって折ります。折った後はテープなどで止めたほうが良いです。</li>
        <li>中・小サイズのお皿は立てて、どんぶりは下に向けます。</li>
        <li>隙間ができないように新聞紙などを詰めます。</li>
      </ul>

      <h3 class="h-sub" style="margin-top:26px;">コップの梱包</h3>
      <ul class="check-list">
        <li>コップは1個ずつ、包み込むように包みます。</li>
        <li>コップは立てて入れていきます。</li>
        <li>隙間ができないように新聞紙を詰めます。</li>
      </ul>

      <div class="notice-box" style="margin-top:22px;">
        <h4>★「われもの注意」の表記</h4>
        <p>段ボールには「われもの注意」の表記を忘れずに。</p>
      </div>
    </div>

    <div class="block">
      <h2 class="h-sec">その他注意すべき家具</h2>
      <p>基本的に小荷物以外は当社が梱包しますが、梱包する前に準備が必要な家具もあります。</p>
      <div class="table-wrap" style="margin-top:18px;">
        <table class="data">
          <tbody>
            <tr><th>冷蔵庫</th><td>中身を空にしておいて下さい（コンセントが抜けない場合はそのままで大丈夫です）。</td></tr>
            <tr><th>洗濯機</th><td>中の水は必ず抜いてください。</td></tr>
            <tr><th>パソコン</th><td>もしものことを考え、データは必ずバックアップを取ってください。（データの保証は致しかねます）</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="block">
      <h2 class="h-sec">なにわのオリジナル梱包材のご紹介</h2>
      <p>なにわ引越センターでは引越時にとても便利な梱包材を多数取り揃えております。小物とはいえお客様にとって大事なお荷物には変わりありません。なにわ引越センターでは小さなお荷物にも細心の注意を払い、お運びいたします。梱包材はお荷物の量に応じて提供しております（一部有料になる場合もございます）。</p>

      <div class="card-grid" style="margin-top:24px;">
        <div class="info-card">
          <h3>ハイパッド（保護材）</h3>
          <p>大小様々なハイパットをご用意しています。幅の広い家具や背の高い家具、壊れやすい家具もスッポリ保護します。大きさが足りない場合も毛布でカバーするので安心です。</p>
        </div>
        <div class="info-card">
          <h3>洗濯機高さ調整ゴムマット</h3>
          <p>洗濯機の振動や騒音をしっかり軽減するゴムマットです。高さを最大45mmまで調整でき、ドラム式・縦型どちらにも対応。ゴム100％だから耐久性も抜群で、床の傷防止にも役立ちます。</p>
        </div>
        <div class="info-card">
          <h3>地震対策グッズ</h3>
          <p>大切な家具を倒壊から防ぐのは、もはや常識になりつつあります。当社でも、引越し時の家具設置の際に、ご希望のお客様には地震対策グッズ（有料）を提供しております。各種取り揃えてご用意がありますので、お気軽にお問い合わせください。</p>
        </div>
      </div>
    </div>

  </div>
</div>

<?php
get_footer();
