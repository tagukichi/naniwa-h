# NANIWA EXPRESS テーマ セットアップ手順

なにわ引越センター公式サイト用のオリジナルテーマ（クラシックテーマ）です。
静的HTMLで確定したデザインをそのまま移植しています。

---

## 1. インストール

1. WordPress 管理画面 → **外観 → テーマ → 新規追加 → テーマのアップロード**
2. `naniwa-express.zip` を選択して「今すぐインストール」→「有効化」

必要環境：WordPress 6.0 以上／PHP 7.4 以上

---

## 2. 固定ページを作る

このテーマは **固定ページのスラッグ**でテンプレートを自動的に割り当てます。
下記のスラッグで固定ページを作成してください（タイトルは自由です）。
本文は空のままで構いません。デザインはテンプレート側に入っています。

| スラッグ | ページ |
|---|---|
| `single` | 単身の引越 |
| `family` | ご家族の引越 |
| `couple` | カップルの引越 |
| `now` | 今すぐの引越 |
| `office` | オフィスの引越 |
| `disused` | 不用品処分 |
| `flow` | 引越全体の流れ |
| `packing` | 梱包の仕方 |
| `others` | 電気工事、ペット、貴重品 |
| `faq` | よくあるご質問 |
| `checklist` | 引越前後やることリスト |
| `company` | 会社案内 |
| `kiyaku` | 運送約款 |
| `recruit` | 求人情報 |
| `estimate-step1` 〜 `estimate-step5` | web見積 STEP1〜5 |
| `estimate-step6-1` / `estimate-step6-2` / `estimate-step6-3` | web見積 荷物情報 |
| `estimate-step7` | web見積 STEP7 |
| `estimate-confirm` | web見積 確認画面 |
| `estimate-thanks` | web見積 完了 |

さらに、ブログ用に固定ページを1つ（例：スラッグ `blog`、タイトル「ブログ」）作り、
**設定 → 表示設定** で以下を指定してください。

- ホームページの表示：**固定ページ**
- ホームページ：（指定しない ＝ フロントページ用テンプレートが使われます）
- 投稿ページ：**ブログ**

> ホームページを固定ページに指定しない場合でも `front-page.php` が優先されるため、
> TOPページは常にデザイン通りに表示されます。

---

## 3. 投稿タイプ

| 種類 | 投稿タイプ | 一覧URL |
|---|---|---|
| ブログ | 投稿（標準） | 上記「投稿ページ」に設定したURL |
| お知らせ | `topics` | `/topics/` |
| お客様の声 | `voice` | `/voice/` |

投稿タイプは **ACF が登録済みならテーマ側では登録しません**。
ACF を使わない環境ではテーマが同じ設定で登録するので、どちらでも動きます。

### お客様の声の入力項目（ACF）

旧サイトの ACF フィールドをそのまま使います。

| フィールド名 | ラベル | 用途 |
|---|---|---|
| `rating` | 評価画像 | 顔アイコンと★の判定（1〜5） |
| `kinds` | 引越の種別 | 単身の引越／ご家族の引越 など |
| `grade` | グレード | スタンダード など |
| `place` | 地域 | 磯子区→中区 |
| `introduction` | 冒頭文章 | 一覧カードの本文 |
| `age` / `gender` | 年代 / 性別 | 一覧・詳細の属性表示 |
| `date` | 評価日 | 詳細の概要テーブル |
| `sagyoubi` | 作業日 | 詳細の概要テーブル |
| `fee` | 料金 | 詳細の概要テーブル（カンマを自動付与） |
| `rating_reception` ほか7項目 | 各評価 | 詳細の「項目別のご評価」 |
| `good` / `bad` | 良かった点 / 悪かった点 | 詳細 |
| `message` | メッセージ | 「なにわ引越センターより」の返信 |

`rating` が空の場合は `rating_total`（満足度）、それも空なら
値の入っている評価軸の平均を使います。

ACF が無効な環境では、テーマが簡易的な入力欄を代わりに表示します。

---

## 4. フォーム

### 求人応募フォーム

**外観 → カスタマイズ → なにわ：フォーム設定** に Contact Form 7 等の
ショートコードを貼り付けると、求人ページのフォームがそれに置き換わります。
空欄のあいだはデザイン確認用のダミーフォームが表示されます（送信はされません）。

### web見積フォーム（STEP1〜7）

テーマ内で完結しています。プラグインは不要です。

- 各ステップは POST で次のステップへ値を引き継ぎます
- 確認画面で入力内容を一覧表示し、「修正する」で各ステップへ戻れます（入力内容は保持されます）
- 送信すると `wp_mail()` で **管理者メールアドレス**（設定 → 一般）宛に通知し、
  `/estimate-thanks/` へリダイレクトします

送信先を変えたい場合は、子テーマや functions.php で以下のフィルターを使ってください。

```php
add_filter( 'naniwa_estimate_mail_to', function () {
	return 'info@naniwa-h.com';
} );
```

> **本番前に必ず実機でテスト送信してください。** レンタルサーバーによっては
> `wp_mail()` が届かないことがあるため、WP Mail SMTP などの導入を推奨します。

---

## 5. 見積CTAを出さないページ

求人ページと見積フォーム内では、フッター上の見積CTA帯とスマホ固定バーを非表示にしています。
他のページも同様にしたい場合は、フィルターでスラッグを追加してください。

```php
add_filter( 'naniwa_no_estimate_cta_slugs', function ( $slugs ) {
	$slugs[] = 'company';
	return $slugs;
} );
```

---

## 6. ファイル構成

```
naniwa-express/
├── style.css                  テーマ情報（実CSSは assets/css/style.css）
├── functions.php              初期設定・アセット読み込み
├── header.php / footer.php    共通ヘッダー・フッター
├── front-page.php             TOP
├── page-{slug}.php            固定ページ（スラッグで自動割り当て）
├── home.php / single.php      ブログ一覧・詳細
├── archive-voice.php / single-voice.php   お客様の声
├── archive-news.php / single-news.php     お知らせ
├── archive.php / search.php / 404.php / page.php
├── inc/
│   ├── cpt.php                カスタム投稿タイプ
│   ├── meta-voice.php         お客様の声のカスタムフィールド
│   ├── template-tags.php      テンプレート用ヘルパー
│   ├── estimate-fields.php    見積フォームの項目定義（自動生成）
│   └── estimate.php           見積フォームの送信処理
└── assets/                    CSS / JS / 画像
```

---

## 7. デザインを更新するとき

このテーマは静的サイトのソース（`src/`）から自動生成しています。
デザインを変えるときは静的側を直してから再生成してください。

```bash
python3 tools/build.py        # 静的サイトを再ビルド
python3 tools/build_theme.py  # テーマと ZIP を再生成
```

`inc/estimate-fields.php` と `page-*.php` は自動生成物です。直接編集しても
次回の再生成で上書きされます。

---

## 8. ナビゲーションの編集について

ドロワーメニューとフッターのリンクは、アイコン付きの独自マークアップのため
`header.php` / `footer.php` に直接記述しています。項目を増減するときは
静的サイトの `src/partials/` を編集して再生成してください。
