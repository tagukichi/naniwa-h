<?php
/**
 * 固定ページ：カップルの引越（スラッグ: couple）
 *
 * Template Name: カップルの引越
 *
 * @package naniwa
 */

get_header();
?>

<section class="page-head">
  <div class="inner"><div class="ph-copy">
    <span class="en">COUPLE</span>
    <h1>カップルの引越</h1>
    <p class="page-lead">新生活を応援！お2人の新しい門出をお祝い</p>
  </div><p class="ph-chara"><img src="<?php echo esc_url( get_theme_file_uri( '/assets/img/chars/chara-couple.svg' ) ); ?>" alt=""></p></div>
</section>

<nav class="breadcrumb" aria-label="パンくずリスト">
  <div class="inner">
    <ol>
      <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">ホーム</a></li>
      <li>カップルの引越</li>
    </ol>
  </div>
</nav>

<div class="page-body">
  <div class="inner">

    <div class="lead-block">
      <h2>新生活を応援！<br><span class="mark">お2人の新しい門出をお祝い</span></h2>
      <p>これから始まる二人の新しい未来。二人で迎える朝。同じ空気。同じ時間。何もかもが心躍ることでしょう。なにわ引越センターでは、そんなステキなお二人を祝福するべく、お得でリーズナブルな引越プランをご用意しております。</p>
    </div>

    <div class="block">
      <div class="plan-detail">
        <p class="ribbon">お2人のお荷物を、1台のトラックで</p>
        <div class="pd-body">
          <h3>抜群にお得なカップル割引プラン</h3>
          <p>お2人の引越地が同じ目的地の場合、なにわのトラックをそれぞれ2台出して、別々にお運びすることもお得にご提案致しますが、弊社担当者にその旨をお伝え頂ければ、<strong>お2人のお荷物を、1台のトラックでお運びすることができる</strong>というものです。つまり、断然お得な料金でいて、しかもスムーズなお引越が可能になります。</p>
          <p class="note">※引越地どうしがとても近いという場合でも、ご利用いただける場合がありますので、お気軽にお問い合わせくださいませ。</p>
                  <div class="diagram-block"><img src="<?php echo esc_url( get_theme_file_uri( '/assets/img/chars/diagram-couple.svg' ) ); ?>" alt="お客様Aとお客様Bのお荷物を、1台のトラックで一緒に新居へ運ぶ図" loading="lazy"></div>
        </div>
      </div>
    </div>

    <div class="block">
      <h2 class="h-sec">別離のお引越しにも対応しています</h2>
      <div class="notice-box">
        <h4>夫婦、ルームシェアの別離にも対応しています。</h4>
        <p>上記の場合とは逆に、同居状態からの別離をお考えになっているお客様にも、お安いお値段で引越いただけます。ご希望のお客様はなにわ引越センターまでお問い合わせください。</p>
        <p class="note" style="margin-top:10px;">プライバシーに配慮した対応も可能です。もちろん秘密は厳守いたします。</p>
      </div>
    </div>

    <div class="block">
      <h2 class="h-sec">お2人の新生活を、まるごとサポート</h2>
      <div class="card-grid">
        <div class="info-card">
          <h3>梱包資材が無料</h3>
          <p>段ボール・ガムテープ・食器梱包用紙を無料でご提供。お2人分をまとめてお届けします。</p>
        </div>
        <div class="info-card">
          <h3>不用品の処分も</h3>
          <p>お2人分の家具が重なってしまった場合も、不用品の処分をあわせて承ります。</p>
        </div>
        <div class="info-card">
          <h3>家具の組み立て・設置</h3>
          <p>新居での家具の組み立てや家電の取り付けもお手伝い。すぐに新生活を始められます。</p>
        </div>
      </div>
    </div>

  </div>
</div>

<?php
get_footer();
